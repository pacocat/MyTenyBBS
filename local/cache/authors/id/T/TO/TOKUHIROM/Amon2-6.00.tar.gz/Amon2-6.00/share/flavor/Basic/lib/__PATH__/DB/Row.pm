package <% $module %>::DB::Row;
use strict;
use warnings;
use utf8;
use parent qw(Teng::Row);

1;
