package Extended::V::MT::Context;
use Amon2::Declare;
1;
