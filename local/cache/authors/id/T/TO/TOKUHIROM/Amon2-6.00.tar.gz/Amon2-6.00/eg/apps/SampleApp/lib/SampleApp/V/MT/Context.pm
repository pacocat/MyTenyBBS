package SampleApp::V::MT::Context;
use Amon2::V::MT::Context;
1;
