package SampleApp;
use Amon2 (
  view_class => 'Text::MicroTemplate::File',
);
1;
